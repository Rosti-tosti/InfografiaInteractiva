using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

namespace Pathfinding
{
    // Controla la secuencia de inicio (Figma: Bienvenida -> Asignando guia -> Cargando -> Byte -> Menu).
    // Todas las pantallas son GameObjects reales en Canvas/Pantallas; aca solo se activan / desactivan.
    public class IntroFlow : MonoBehaviour
    {
        [Header("Pantallas (en orden)")]
        public GameObject s00Bienvenida;
        public GameObject s01AsignandoGuia;
        public GameObject s02Cargando;
        public GameObject s03ByteHola;
        public GameObject s04Menu;
        public GameObject s05PathfindingElegido;
        public GameObject s06MaquinaElegida;

        [Header("Botones")]
        public Button btnComenzar;
        public Button btnEntendido;
        public Button cardPathfinding;
        public Button cardMaquina;
        public Button btnElegirPathfinding;
        public Button btnElegirMaquina;
        public Button miniMaquina;      // tarjeta chica en S05
        public Button miniPathfinding;  // tarjeta chica en S06

        [Header("Siguiente escena (Pathfinding)")]
        public string escenaPathfinding = "Escena1";
        public float segundosCargando = 2f;

        GameObject[] todas;
        int actual = -1;

        void Start()
        {
            todas = new[] { s00Bienvenida, s01AsignandoGuia, s02Cargando, s03ByteHola, s04Menu, s05PathfindingElegido, s06MaquinaElegida };
            Click(btnComenzar, () => Ir(1));
            Click(btnEntendido, () => Ir(2));
            Click(cardPathfinding, () => Ir(5));
            Click(cardMaquina, () => Ir(6));
            Click(miniMaquina, () => Ir(6));
            Click(miniPathfinding, () => Ir(5));
            Click(btnElegirPathfinding, ElegirPathfinding);
            Click(btnElegirMaquina, () => Debug.Log("Maquina de Estados: capitulo pendiente de portar."));
            Ir(0);
        }

        static void Click(Button b, UnityEngine.Events.UnityAction a) { if (b != null) b.onClick.AddListener(a); }

        void Ir(int i)
        {
            StopAllCoroutines();
            actual = i;
            for (int k = 0; k < todas.Length; k++) if (todas[k] != null) todas[k].SetActive(k == i);
            if (i == 2) StartCoroutine(Esperar(segundosCargando, () => Ir(3)));
        }

        IEnumerator Esperar(float s, System.Action fin) { yield return new WaitForSeconds(s); fin(); }

        void ElegirPathfinding()
        {
            if (Application.CanStreamedLevelBeLoaded(escenaPathfinding)) SceneManager.LoadScene(escenaPathfinding);
            else Debug.Log("Escena '" + escenaPathfinding + "' todavia no existe (se arma en la siguiente entrega).");
        }

        void Update()
        {
            bool avanzar = Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter);
            bool izq = Input.GetKeyDown(KeyCode.LeftArrow), der = Input.GetKeyDown(KeyCode.RightArrow);
            switch (actual)
            {
                case 0: if (avanzar) Ir(1); break;
                case 1: if (avanzar) Ir(2); break;
                case 2: if (avanzar) Ir(3); break;
                case 3: if (avanzar) Ir(4); break;
                case 4: if (izq) Ir(5); else if (der) Ir(6); break;
                case 5: if (der) Ir(6); else if (avanzar) ElegirPathfinding(); break;
                case 6: if (izq) Ir(5); break;
            }
        }
    }
}
