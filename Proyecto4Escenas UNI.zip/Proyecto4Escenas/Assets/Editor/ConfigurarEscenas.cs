using UnityEditor;
using UnityEngine;
using UnityEditor.SceneManagement;
using System.Collections.Generic;
using Pathfinding;

// Menú: Tools > Configurar 4 Escenas
// Regenera las 4 escenas de la infografía "Pathfinding" y las agrega a Build Settings.
// (Las escenas ya vienen configuradas; usá esto solo si querés regenerarlas.)
public static class ConfigurarEscenas
{
    [MenuItem("Tools/Configurar 4 Escenas")]
    public static void Configurar()
    {
        var build = new List<EditorBuildSettingsScene>();
        for (int i = 1; i <= 4; i++)
        {
            string path = $"Assets/Scenes/Escena{i}.unity";
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            var cgo = new GameObject($"Camara_Escena{i}");
            cgo.tag = "MainCamera";
            cgo.transform.position = new Vector3(0, 0, -10);
            var cam = cgo.AddComponent<Camera>();
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = Paleta.Fondo;
            cgo.AddComponent<AudioListener>();

            var go = new GameObject("Escena");
            switch (i)
            {
                case 1: go.AddComponent<Escena1Intro>(); break;
                case 2: go.AddComponent<Escena2Laberinto>(); break;
                case 3: go.AddComponent<Escena3Comparacion>(); break;
                case 4: go.AddComponent<Escena4Explicacion>(); break;
            }
            EditorSceneManager.SaveScene(scene, path);
            build.Add(new EditorBuildSettingsScene(path, true));
        }
        EditorBuildSettings.scenes = build.ToArray();
        Debug.Log("4 escenas de Pathfinding creadas y agregadas a Build Settings.");
    }
}
