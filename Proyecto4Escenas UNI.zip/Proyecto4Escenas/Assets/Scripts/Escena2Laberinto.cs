using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Pathfinding
{
    // Escena 2: laberinto 7x7 en 3D, primera persona.
    // Mover: WASD · Mirar: mouse · Disparar / elegir: click izquierdo · Soltar mouse: Esc
    public class Escena2Laberinto : EscenaBase
    {
        const float Celda = 4f, Alto = 3.4f, Velocidad = 4.2f, Sens = 2.2f;

        // Jugador
        Transform jugador, cam, arma;
        CharacterController cc;
        float yaw, pitch, yawObjetivo;
        bool girando, bloqueado = true;
        float retroceso;
        Light destello;
        float tDestello;

        // Estado del recorrido
        readonly List<Vector2Int> recorrido = new List<Vector2Int>();
        Vector2Int celdaActual;
        readonly HashSet<string> hechos = new HashSet<string>();
        Vector2Int? celdaDialogo;

        // UI
        Transform hud, dialogoRaiz;
        Text txtPasos;
        Material matMuro, matPiso, matTecho, matAmarillo, matVerde;

        static Vector3 Centro(Vector2Int c) { return new Vector3(c.x * Celda, 0f, -c.y * Celda); }

        protected override void Awake()
        {
            var vieja = Camera.main;
            if (vieja != null) Destroy(vieja.gameObject);
            base.Awake();
            Cursor.lockState = CursorLockMode.Locked; Cursor.visible = false;
        }

        void Start()
        {
            CrearMateriales();
            ConstruirMundo();
            CrearJugador();
            CrearHud();
            celdaActual = Laberinto.A;
            recorrido.Add(celdaActual);
            Dialogo("entrada");
        }

        // ------------------------------------------------------------
        //  Mundo 3D
        // ------------------------------------------------------------
        Material Mat(Color c, bool emisivo = false)
        {
            var tmp = GameObject.CreatePrimitive(PrimitiveType.Cube);
            var m = new Material(tmp.GetComponent<Renderer>().sharedMaterial);
            Destroy(tmp);
            m.color = c;
            if (emisivo) { m.EnableKeyword("_EMISSION"); m.SetColor("_EmissionColor", c * 1.6f); }
            return m;
        }

        void CrearMateriales()
        {
            matMuro = Mat(new Color(0.27f, 0.33f, 0.27f));
            matPiso = Mat(new Color(0.16f, 0.15f, 0.13f));
            matTecho = Mat(new Color(0.12f, 0.13f, 0.12f));
            matAmarillo = Mat(Paleta.Amarillo, true);
            matVerde = Mat(Paleta.Verde, true);
            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
            RenderSettings.ambientLight = new Color(0.10f, 0.12f, 0.10f);
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.ExponentialSquared;
            RenderSettings.fogColor = new Color(0.03f, 0.05f, 0.04f);
            RenderSettings.fogDensity = 0.035f;
        }

        GameObject Caja3D(string n, Vector3 pos, Vector3 esc, Material m, Transform padre, bool colision = true)
        {
            var g = GameObject.CreatePrimitive(PrimitiveType.Cube);
            g.name = n; g.transform.SetParent(padre, false);
            g.transform.localPosition = pos; g.transform.localScale = esc;
            g.GetComponent<Renderer>().sharedMaterial = m;
            if (!colision) Destroy(g.GetComponent<Collider>());
            return g;
        }

        void ConstruirMundo()
        {
            var raiz = new GameObject("Laberinto").transform;
            int n = Laberinto.N;
            for (int j = 0; j < n; j++)
                for (int i = 0; i < n; i++)
                {
                    var c = new Vector2Int(i, j);
                    var p = Centro(c);
                    if (Laberinto.Muro(c))
                    {
                        Caja3D("Muro_" + i + "_" + j, p + Vector3.up * (Alto * 0.5f), new Vector3(Celda, Alto, Celda), matMuro, raiz);
                        continue;
                    }
                    Caja3D("Piso_" + i + "_" + j, p + Vector3.down * 0.05f, new Vector3(Celda, 0.1f, Celda), matPiso, raiz);
                    Caja3D("Techo_" + i + "_" + j, p + Vector3.up * (Alto + 0.05f), new Vector3(Celda, 0.1f, Celda), matTecho, raiz, false);

                    if ((i + j) % 2 == 0)
                    {
                        var go = new GameObject("Lampara_" + i + "_" + j);
                        go.transform.SetParent(raiz, false);
                        go.transform.position = p + Vector3.up * (Alto - 0.4f);
                        var l = go.AddComponent<Light>();
                        l.type = LightType.Point; l.color = new Color(1f, 0.72f, 0.38f);
                        l.range = 8.5f; l.intensity = 1.4f; l.shadows = LightShadows.None;
                        Caja3D("Foco", go.transform.localPosition, new Vector3(0.35f, 0.18f, 0.35f), matAmarillo, go.transform, false);
                        go.transform.GetChild(0).localPosition = Vector3.zero;
                    }
                }

            // Marcas A y B en el piso
            Marca(Laberinto.A, matAmarillo, "A", Paleta.Amarillo, raiz);
            Marca(Laberinto.B, matVerde, "B", Paleta.Verde, raiz);

            // Placas de elección junto a cada bifurcación
            Placa(new Vector2Int(2, 3), raiz); Placa(new Vector2Int(4, 3), raiz);   // bifurcación 1
            Placa(new Vector2Int(5, 2), raiz); Placa(new Vector2Int(5, 4), raiz);   // bifurcación 2
        }

        void Marca(Vector2Int c, Material m, string letra, Color col, Transform padre)
        {
            Caja3D("Marca" + letra, Centro(c) + Vector3.up * 0.02f, new Vector3(2.2f, 0.04f, 2.2f), m, padre, false);
            var go = new GameObject("Letra" + letra);
            go.transform.SetParent(padre, false);
            go.transform.position = Centro(c) + Vector3.up * 2.2f;
            var tm = go.AddComponent<TextMesh>();
            tm.text = letra; tm.font = UIKit.Fuente; tm.fontSize = 80; tm.characterSize = 0.08f;
            tm.anchor = TextAnchor.MiddleCenter; tm.color = col;
            go.GetComponent<MeshRenderer>().sharedMaterial = UIKit.Fuente.material;
            go.AddComponent<Billboard>();
        }

        void Placa(Vector2Int c, Transform padre)
        {
            Caja3D("Placa", Centro(c) + Vector3.up * 0.02f, new Vector3(1.6f, 0.04f, 1.6f), matAmarillo, padre, false);
        }

        // ------------------------------------------------------------
        //  Jugador
        // ------------------------------------------------------------
        void CrearJugador()
        {
            var go = new GameObject("Jugador");
            go.transform.position = Centro(Laberinto.A) + Vector3.up * 0.1f;
            jugador = go.transform;
            cc = go.AddComponent<CharacterController>();
            cc.height = 1.8f; cc.radius = 0.35f; cc.center = new Vector3(0, 0.9f, 0);

            var cgo = new GameObject("Camara");
            cgo.tag = "MainCamera";
            cgo.transform.SetParent(jugador, false);
            cgo.transform.localPosition = new Vector3(0, 1.65f, 0);
            cam = cgo.transform;
            var c = cgo.AddComponent<Camera>();
            c.fieldOfView = 70f; c.nearClipPlane = 0.05f;
            c.clearFlags = CameraClearFlags.SolidColor; c.backgroundColor = new Color(0.02f, 0.03f, 0.025f);
            cgo.AddComponent<AudioListener>();

            // Arma (modelo simple)
            var a = GameObject.CreatePrimitive(PrimitiveType.Cube);
            Destroy(a.GetComponent<Collider>());
            a.name = "Arma"; a.transform.SetParent(cam, false);
            a.transform.localPosition = new Vector3(0.28f, -0.24f, 0.55f);
            a.transform.localScale = new Vector3(0.09f, 0.12f, 0.55f);
            a.GetComponent<Renderer>().sharedMaterial = Mat(new Color(0.12f, 0.13f, 0.12f));
            arma = a.transform;

            var lgo = new GameObject("Destello");
            lgo.transform.SetParent(cam, false);
            lgo.transform.localPosition = new Vector3(0.28f, -0.2f, 0.9f);
            destello = lgo.AddComponent<Light>();
            destello.type = LightType.Point; destello.color = new Color(1f, 0.8f, 0.4f);
            destello.range = 6f; destello.intensity = 0f; destello.shadows = LightShadows.None;

            yaw = 90f; yawObjetivo = 90f;           // mirando al este
            jugador.rotation = Quaternion.Euler(0, yaw, 0);
        }

        // ------------------------------------------------------------
        //  HUD
        // ------------------------------------------------------------
        Text txtSeccion, txtPie;

        void CrearHud()
        {
            hud = UIKit.CrearRaiz(canvas.transform, "HUD");
            // fondo opaco del canvas base: lo ocultamos para ver el 3D
            var fondo = canvas.transform.Find("FondoRaiz");
            if (fondo != null) fondo.gameObject.SetActive(false);

            var c = UIKit.NuevaCaja(hud, 37, 28, 1383, 58, new Color(0.07f, 0.11f, 0.09f, 0.88f), Paleta.VerdeBorde, 2f);
            UIKit.Texto(c.rt, "SINTÉTIKA / IA EN JUEGO", 22, 0, 600, 58, 17, Paleta.Verde, TextAnchor.MiddleLeft, FontStyle.Bold);
            txtSeccion = UIKit.Texto(c.rt, "LABERINTO 3D / ENTRADA", 1383 - 722, 0, 700, 58, 17, Paleta.Crema, TextAnchor.MiddleRight, FontStyle.Bold);

            var cp = UIKit.NuevaCaja(hud, 1180, 98, 240, 44, new Color(0.07f, 0.11f, 0.09f, 0.88f), Paleta.Amarillo, 2f);
            txtPasos = UIKit.Texto(cp.rt, "PASOS  00", 0, 0, 240, 44, 20, Paleta.Amarillo, TextAnchor.MiddleCenter, FontStyle.Bold);

            txtPie = UIKit.Texto(hud, "APUNTÁ PARA ELEGIR · DISPARÁ PARA AVANZAR", 37, 776, 800, 20, 13, Paleta.Gris, TextAnchor.MiddleLeft, FontStyle.Bold);
            UIKit.Texto(hud, "LABERINTO 3D / PRIMERA PERSONA", 619, 776, 800, 20, 13, Paleta.Gris, TextAnchor.MiddleRight, FontStyle.Bold);
            UIKit.Mira(hud, new Color(0.60f, 0.74f, 0.53f, 0.9f));
            ActualizarPasos();
        }

        void ActualizarPasos() { txtPasos.text = "PASOS  " + Mathf.Max(0, recorrido.Count - 1).ToString("00"); }

        // ------------------------------------------------------------
        //  Diálogos (cada uno corresponde a una diapositiva)
        // ------------------------------------------------------------
        void CerrarDialogo()
        {
            if (dialogoRaiz != null) { dialogoRaiz.gameObject.SetActive(false); Destroy(dialogoRaiz.gameObject); dialogoRaiz = null; }
            bloqueado = false;
            txtPie.text = "APUNTÁ PARA ELEGIR · DISPARÁ PARA AVANZAR";
        }

        void Dialogo(string id)
        {
            CerrarDialogo();
            bloqueado = true;
            dialogoRaiz = UIKit.CrearRaiz(canvas.transform, "Dialogo_" + id);
            var d = dialogoRaiz;
            string texto = "", seccion = "LABERINTO 3D / ENTRADA";
            switch (id)
            {
                case "entrada":
                    texto = "Ahí vamos. El minimapa se apagó: de acá en adelante, elegís a ojo.";
                    UIKit.Boton(d, "[ + ]", "Avanzar", 1047, 639, 353, 73, CerrarDialogo, KeyCode.Return); break;
                case "rival":
                    texto = "Parece que vas a ser un buen rival, pero jamás podrás conmigo, sigamos.";
                    UIKit.Boton(d, "[ + ]", "Avanzar", 1047, 639, 353, 73, CerrarDialogo, KeyCode.Return); break;
                case "bif1":
                    seccion = "LABERINTO 3D / BIFURCACIÓN";
                    texto = "Primera bifurcación. Una IA evaluaría las dos opciones antes de moverse; vos tenés que decidir ya.";
                    Elegir(d); break;
                case "bif2":
                    seccion = "LABERINTO 3D / BIFURCACIÓN";
                    texto = "Mmmm seguro que es por acá? a ver quien llega primero";
                    Elegir(d); break;
                case "callejon":
                    seccion = "LABERINTO 3D / CALLEJÓN SIN SALIDA";
                    texto = "Callejón sin salida. Yo nunca entro acá: calculo el costo de cada camino antes de dar un paso. Volvé a la bifurcación.";
                    UIKit.Boton(d, "[ ← ]", "Volver atrás", 1047, 639, 353, 73, () => { Girar(180f); CerrarDialogo(); }, KeyCode.Return); break;
                case "llegada":
                    seccion = "LABERINTO 3D / LLEGADA A B";
                    texto = "Llegaste. Pero no lo suficientemente rapido JaJAJa. Veamos cuántos pasos te costó.";
                    UIKit.Boton(d, "[ + ]", "Ver comparación", 1047, 639, 353, 73, Terminar, KeyCode.Return); break;
            }
            UIKit.Dialogo(d, 55, 592, 890, 166, "BYTE / IA CORRUPTA", texto);
            txtSeccion.text = seccion;
            if (id == "bif1" || id == "bif2") txtPie.text = "ELEGÍ IZQUIERDA O DERECHA";
        }

        void Elegir(Transform d)
        {
            UIKit.Boton(d, "[ ← ]", "IZQUIERDA", 154, 380, 274, 102, () => { Girar(-90f); CerrarDialogo(); }, KeyCode.LeftArrow);
            UIKit.Boton(d, "[ → ]", "DERECHA", 1028, 380, 274, 102, () => { Girar(90f); CerrarDialogo(); }, KeyCode.RightArrow);
        }

        void Girar(float grados) { yawObjetivo = Mathf.Round(yaw / 90f) * 90f + grados; girando = true; }

        void Terminar()
        {
            DatosPartida.Recorrido = new List<Vector2Int>(recorrido);
            Cursor.lockState = CursorLockMode.None; Cursor.visible = true;
            IrAEscena("Escena3");
        }

        // ------------------------------------------------------------
        //  Bucle principal
        // ------------------------------------------------------------
        void Update()
        {
            if (jugador == null) return;
            if (Input.GetKeyDown(KeyCode.Escape)) { Cursor.lockState = CursorLockMode.None; Cursor.visible = true; }
            if (Cursor.lockState != CursorLockMode.Locked && Input.GetMouseButtonDown(0))
            { Cursor.lockState = CursorLockMode.Locked; Cursor.visible = false; return; }

            bool uso = ShootButton.Procesar();
            Mirar();
            Mover();
            Seguimiento();
            Disparo(uso);
        }

        void Mirar()
        {
            if (girando)
            {
                yaw = Mathf.MoveTowardsAngle(yaw, yawObjetivo, 260f * Time.deltaTime);
                if (Mathf.Abs(Mathf.DeltaAngle(yaw, yawObjetivo)) < 0.01f) { yaw = yawObjetivo; girando = false; }
            }
            else if (Cursor.lockState == CursorLockMode.Locked)
            {
                yaw += Input.GetAxis("Mouse X") * Sens;
                yawObjetivo = yaw;
            }
            if (Cursor.lockState == CursorLockMode.Locked)
                pitch = Mathf.Clamp(pitch - Input.GetAxis("Mouse Y") * Sens, -75f, 75f);
            jugador.rotation = Quaternion.Euler(0, yaw, 0);
            cam.localRotation = Quaternion.Euler(pitch, 0, 0);
        }

        void Mover()
        {
            Vector3 dir = Vector3.zero;
            if (!bloqueado && !girando)
            {
                dir = jugador.right * Input.GetAxisRaw("Horizontal") + jugador.forward * Input.GetAxisRaw("Vertical");
                if (dir.sqrMagnitude > 1f) dir.Normalize();
            }
            cc.SimpleMove(dir * Velocidad);
        }

        // Cuenta pasos y dispara los diálogos de cada tramo
        void Seguimiento()
        {
            var p = jugador.position;
            var c = new Vector2Int(Mathf.RoundToInt(p.x / Celda), Mathf.RoundToInt(-p.z / Celda));
            if (c != celdaActual && !Laberinto.Muro(c))
            {
                celdaActual = c;
                recorrido.Add(c);
                ActualizarPasos();
            }

            Vector3 centro = Centro(celdaActual);
            float dist = new Vector2(p.x - centro.x, p.z - centro.z).magnitude;
            if (celdaDialogo.HasValue && (celdaDialogo.Value != celdaActual || dist > 1.7f)) celdaDialogo = null;
            if (bloqueado || dist > 1.0f || celdaDialogo == celdaActual) return;

            string id = null;
            if (celdaActual == new Vector2Int(3, 3) && hechos.Add("bif1")) id = "bif1";
            else if (celdaActual == new Vector2Int(4, 3) && hechos.Add("rival")) id = "rival";
            else if (celdaActual == new Vector2Int(5, 3) && hechos.Add("bif2")) id = "bif2";
            else if (celdaActual == new Vector2Int(1, 3) || celdaActual == new Vector2Int(5, 1)) id = "callejon";
            else if (celdaActual == Laberinto.B) id = "llegada";

            if (id != null) { celdaDialogo = celdaActual; Dialogo(id); }
        }

        // ------------------------------------------------------------
        //  Disparo
        // ------------------------------------------------------------
        void Disparo(bool usoBoton)
        {
            if (retroceso > 0) retroceso = Mathf.Max(0, retroceso - Time.deltaTime * 4f);
            arma.localPosition = new Vector3(0.28f, -0.24f, 0.55f - retroceso * 0.12f);
            if (tDestello > 0) { tDestello -= Time.deltaTime; if (tDestello <= 0) destello.intensity = 0f; }

            if (usoBoton || Cursor.lockState != CursorLockMode.Locked || !Input.GetMouseButtonDown(0)) return;
            retroceso = 1f; tDestello = 0.05f; destello.intensity = 3f;
            RaycastHit hit;
            if (Physics.Raycast(cam.position, cam.forward, out hit, 60f))
            {
                var s = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                Destroy(s.GetComponent<Collider>());
                s.transform.position = hit.point + hit.normal * 0.02f;
                s.transform.localScale = Vector3.one * 0.12f;
                s.GetComponent<Renderer>().sharedMaterial = matAmarillo;
                Destroy(s, 0.5f);
            }
        }
    }

    public class Billboard : MonoBehaviour
    {
        void LateUpdate()
        {
            if (Camera.main == null) return;
            var d = transform.position - Camera.main.transform.position; d.y = 0;
            if (d.sqrMagnitude > 0.001f) transform.rotation = Quaternion.LookRotation(d);
        }
    }
}
