using UnityEngine;
using UnityEngine.UI;

namespace Pathfinding
{
    // Escena 1: cargas, misión, "Vos contra la IA" y minimapa.
    public class Escena1Intro : EscenaBase
    {
        int idx = -1;
        float t;
        Text subtitulo;
        string subBase;
        const float DuracionCarga = 3.2f;

        void Start() { Siguiente(); }

        void Siguiente()
        {
            idx++;
            var p = NuevaPantalla();
            t = 0;
            Oscurecer(idx <= 1 ? 0.8f : 0.12f);
            switch (idx)
            {
                case 0: Carga(p, "Buscando la ruta más optima", "VAMOS! NOs vemos aL oTRo laDO"); break;
                case 1: Carga(p, "Estableciendo casilleros", "Tu miSióN es llEgAr al pUntO B, veAmOs qUiEn es máS ráPiDo."); break;
                case 2: Mision(p); break;
                case 3: Rival(p); break;
                case 4: Mapa(p); break;
                default: IrAEscena("Escena2"); break;
            }
        }

        void Update()
        {
            ShootButton.Procesar();
            if (idx >= 0 && idx <= 1)
            {
                t += Time.deltaTime;
                int n = Mathf.Clamp(Mathf.FloorToInt(t / DuracionCarga * 8f), 0, 8);
                if (subtitulo != null) subtitulo.text = subBase + " //" + new string('.', n) + "//";
                if (t >= DuracionCarga || Input.GetMouseButtonDown(0)) Siguiente();
            }
        }

        void Carga(Transform p, string sub, string byteTxt)
        {
            UIKit.Encabezado(p, "Pathfinding/Sintetika", null);
            UIKit.Texto(p, "PATHFINDING", 68, 150, 900, 110, 84, Paleta.Crema, TextAnchor.MiddleLeft, FontStyle.Bold);
            UIKit.Rellenar(p, 74, 284, 123, 4, Paleta.Naranja);
            subBase = sub;
            subtitulo = UIKit.Texto(p, sub + " //........//", 74, 322, 900, 40, 24, Paleta.Gris);
            var c = UIKit.NuevaCaja(p, 237, 611, 910, 120, Paleta.Panel, Paleta.Verde, 2f);
            UIKit.Byte(c.rt, 26, 24, 1f);
            UIKit.Texto(c.rt, "BYTE / Tu gUiA", 114, 20, 600, 20, 13, Paleta.Verde, TextAnchor.UpperLeft, FontStyle.Bold);
            UIKit.Texto(c.rt, byteTxt, 114, 52, 770, 60, 20, Paleta.Crema);
            UIKit.Pie(p, "APUNTÁ PARA ELEGIR · DISPARÁ PARA AVANZAR", null);
        }

        void Fondo3D(Transform p, string der)
        {
            UIKit.Encabezado(p, "SINTÉTIKA / IA EN JUEGO", der);
            UIKit.Pie(p, "APUNTÁ PARA ELEGIR · DISPARÁ PARA AVANZAR", "LABERINTO 3D / INTRODUCCIÓN");
        }

        void Mision(Transform p)
        {
            Fondo3D(p, "INTRODUCCIÓN / MISIÓN");
            UIKit.Texto(p, "Tu misión", 58, 124, 700, 50, 36, Paleta.Crema, TextAnchor.MiddleLeft, FontStyle.Bold);
            var c = UIKit.NuevaCaja(p, 58, 220, 428, 220, Paleta.Panel, Paleta.Verde, 2f);
            UIKit.Texto(c.rt, "OBJETIVO", 16, 16, 300, 18, 12, Paleta.Verde, TextAnchor.UpperLeft, FontStyle.Bold);
            UIKit.Texto(c.rt, "Elegí un camino y encontrá la salida del laberinto.", 16, 46, 396, 80, 20, Paleta.Crema);
            UIKit.Texto(c.rt, "Salís en el punto A y tenés que llegar al punto B.", 16, 132, 396, 70, 17, Paleta.Gris);
            UIKit.Dialogo(p, 55, 592, 890, 166, "BYTE / IA CORRUPTA", "Bienvenido a mi laberinto. Tu trabajo es simple: llegar del punto A al punto B.");
            UIKit.Boton(p, "[ + ]", "Siguiente", 1047, 639, 353, 73, Siguiente, KeyCode.Return);
        }

        void Rival(Transform p)
        {
            Fondo3D(p, "INTRODUCCIÓN / EL RIVAL");
            UIKit.Texto(p, "Vos contra la IA", 58, 124, 700, 50, 36, Paleta.Crema, TextAnchor.MiddleLeft, FontStyle.Bold);
            var a = UIKit.NuevaCaja(p, 236, 220, 426, 220, Paleta.Panel, Paleta.Verde, 2f);
            UIKit.Texto(a.rt, "VOS", 16, 16, 300, 18, 12, Paleta.Verde, TextAnchor.UpperLeft, FontStyle.Bold);
            UIKit.Texto(a.rt, "Elegís izquierda o derecha pisando una placa del piso.", 16, 46, 394, 80, 20, Paleta.Crema);
            UIKit.Texto(a.rt, "Cada paso suma al contador.", 16, 132, 394, 70, 17, Paleta.Gris);
            UIKit.Texto(p, "VS", 662, 270, 132, 80, 50, Paleta.Naranja, TextAnchor.MiddleCenter, FontStyle.Bold);
            var b = UIKit.NuevaCaja(p, 794, 220, 424, 220, new Color(0.14f, 0.10f, 0.08f, 0.96f), Paleta.Naranja, 2f);
            UIKit.Texto(b.rt, "BYTE / IA", 16, 16, 300, 18, 12, Paleta.Naranja, TextAnchor.UpperLeft, FontStyle.Bold);
            UIKit.Texto(b.rt, "Recorre el mismo laberinto que vos.", 16, 46, 392, 80, 20, Paleta.Crema);
            UIKit.Texto(b.rt, "Calcula el costo de cada camino antes de moverse.", 16, 132, 392, 70, 17, Paleta.Gris);
            UIKit.Dialogo(p, 55, 592, 890, 166, "BYTE / IA CORRUPTA", "¿Listo? Veamos quién llega primero a B.");
            UIKit.Boton(p, "[ + ]", "Siguiente", 1047, 639, 353, 73, Siguiente, KeyCode.Return);
        }

        void Mapa(Transform p)
        {
            Fondo3D(p, "INTRODUCCIÓN / EL MAPA");
            var c = UIKit.NuevaCaja(p, 428, 97, 517, 484, Paleta.Panel, Paleta.Verde, 2f);
            UIKit.Texto(c.rt, "MINIMAPA / A Y B", 38, 40, 440, 30, 22, Paleta.Verde, TextAnchor.UpperLeft, FontStyle.Bold);
            MapaUI.Dibujar(p, 428 + 78.5f, 186, 360, 4);
            UIKit.Dialogo(p, 55, 592, 890, 166, "BYTE / IA CORRUPTA", "Una vez adentro, el minimapa se apaga y quedás solo con tu intuición. Memorizá lo que puedas.");
            UIKit.Boton(p, "[ + ]", "Empezar", 1047, 639, 353, 73, Siguiente, KeyCode.Return);
        }
    }
}
