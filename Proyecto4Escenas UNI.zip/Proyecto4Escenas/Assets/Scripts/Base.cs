using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

namespace Pathfinding
{
    // ---------------------------------------------------------------
    //  Paleta (tomada de los PNG de la infografía)
    // ---------------------------------------------------------------
    public static class Paleta
    {
        public static readonly Color Fondo = new Color(0.055f, 0.078f, 0.067f);
        public static readonly Color Panel = new Color(0.075f, 0.118f, 0.098f, 0.96f);
        public static readonly Color Verde = new Color(0.60f, 0.74f, 0.53f);
        public static readonly Color VerdeBorde = new Color(0.43f, 0.57f, 0.40f);
        public static readonly Color Amarillo = new Color(0.91f, 0.76f, 0.42f);
        public static readonly Color Crema = new Color(0.96f, 0.93f, 0.85f);
        public static readonly Color Gris = new Color(0.72f, 0.77f, 0.68f);
        public static readonly Color Naranja = new Color(0.88f, 0.50f, 0.35f);
        public static readonly Color Muro = new Color(0.39f, 0.43f, 0.37f);
        public static readonly Color Piso = new Color(0.10f, 0.14f, 0.12f);
        public static readonly Color Oscuro = new Color(0.08f, 0.10f, 0.07f);
    }

    // ---------------------------------------------------------------
    //  Laberinto 7x7 (incluye el marco de muros). '#' muro, '.' libre
    //  Coordenadas: x = columna, y = fila (0 arriba).
    // ---------------------------------------------------------------
    public static class Laberinto
    {
        public const int N = 7;
        public static readonly string[] Mapa =
        {
            "#######",
            "#A..#.#",
            "###.#.#",
            "#.....#",
            "#####.#",
            "#####B#",
            "#######",
        };
        public static readonly Vector2Int A = new Vector2Int(1, 1);
        public static readonly Vector2Int B = new Vector2Int(5, 5);

        public static bool Muro(int x, int y)
        {
            if (x < 0 || y < 0 || x >= N || y >= N) return true;
            return Mapa[y][x] == '#';
        }
        public static bool Muro(Vector2Int c) { return Muro(c.x, c.y); }
    }

    // ---------------------------------------------------------------
    //  A* real sobre el laberinto (4 vecinos, heurística Manhattan)
    // ---------------------------------------------------------------
    public static class AEstrella
    {
        public static List<Vector2Int> Buscar(Vector2Int ini, Vector2Int meta)
        {
            var g = new Dictionary<Vector2Int, int>();
            var previo = new Dictionary<Vector2Int, Vector2Int>();
            var abiertos = new List<Vector2Int> { ini };
            var cerrados = new HashSet<Vector2Int>();
            g[ini] = 0;
            Vector2Int[] dirs = { Vector2Int.right, Vector2Int.down, Vector2Int.left, Vector2Int.up };

            while (abiertos.Count > 0)
            {
                int mejor = 0;
                for (int i = 1; i < abiertos.Count; i++)
                    if (F(abiertos[i], g, meta) < F(abiertos[mejor], g, meta)) mejor = i;
                var actual = abiertos[mejor];
                abiertos.RemoveAt(mejor);

                if (actual == meta)
                {
                    var ruta = new List<Vector2Int> { actual };
                    while (previo.ContainsKey(actual)) { actual = previo[actual]; ruta.Insert(0, actual); }
                    return ruta;
                }
                cerrados.Add(actual);
                foreach (var d in dirs)
                {
                    var v = actual + d;
                    if (Laberinto.Muro(v) || cerrados.Contains(v)) continue;
                    int ng = g[actual] + 1;
                    if (!g.ContainsKey(v) || ng < g[v])
                    {
                        g[v] = ng; previo[v] = actual;
                        if (!abiertos.Contains(v)) abiertos.Add(v);
                    }
                }
            }
            return new List<Vector2Int>();
        }

        static int F(Vector2Int n, Dictionary<Vector2Int, int> g, Vector2Int meta)
        {
            return g[n] + Mathf.Abs(n.x - meta.x) + Mathf.Abs(n.y - meta.y);
        }
    }

    // Datos que pasan de la escena 2 (laberinto) a la 3 (comparación)
    public static class DatosPartida
    {
        public static List<Vector2Int> Recorrido = new List<Vector2Int>();
        public static int Pasos { get { return Mathf.Max(0, Recorrido.Count - 1); } }
    }

    // ---------------------------------------------------------------
    //  Botones que se activan "disparando" con la mira (o con el mouse)
    // ---------------------------------------------------------------
    public class ShootButton : MonoBehaviour
    {
        public static readonly List<ShootButton> Todos = new List<ShootButton>();
        public Action onClick;
        public KeyCode tecla = KeyCode.None;
        public Image relleno;
        public Color normal, resaltado;
        public bool bajoMira;

        void OnEnable() { Todos.Add(this); }
        void OnDisable() { Todos.Remove(this); bajoMira = false; }

        public void SetResaltado(bool v)
        {
            bajoMira = v;
            if (relleno != null) relleno.color = v ? resaltado : normal;
        }

        // Llamar una vez por frame. Devuelve true si se activó un botón.
        public static bool Procesar()
        {
            Vector2 p = Cursor.lockState == CursorLockMode.Locked
                ? new Vector2(Screen.width * 0.5f, Screen.height * 0.5f)
                : (Vector2)Input.mousePosition;

            var copia = Todos.ToArray();
            ShootButton top = null;
            foreach (var b in copia)
            {
                if (b == null || !b.gameObject.activeInHierarchy) continue;
                bool dentro = RectTransformUtility.RectangleContainsScreenPoint((RectTransform)b.transform, p, null);
                b.SetResaltado(dentro);
                if (dentro) top = b;
            }

            if (Input.GetMouseButtonDown(0) && top != null && top.onClick != null)
            {
                top.onClick(); return true;
            }
            foreach (var b in copia)
            {
                if (b == null || !b.gameObject.activeInHierarchy) continue;
                if (b.tecla != KeyCode.None && Input.GetKeyDown(b.tecla) && b.onClick != null)
                {
                    b.onClick(); return true;
                }
            }
            return false;
        }
    }

    // ---------------------------------------------------------------
    //  Utilidades de UI (coordenadas en el espacio 1456 x 819 de los PNG)
    // ---------------------------------------------------------------
    public struct Caja { public RectTransform rt; public Image fill; public Image borde; }

    public static class UIKit
    {
        public const float W = 1456f, H = 819f;
        static Font fuente;

        public static Font Fuente
        {
            get
            {
                if (fuente == null)
                    fuente = Font.CreateDynamicFontFromOSFont(new[] { "Consolas", "Courier New", "Menlo", "DejaVu Sans Mono" }, 32);
                return fuente;
            }
        }

        public static Canvas CrearCanvas(string nombre, int orden = 0)
        {
            var go = new GameObject(nombre);
            var c = go.AddComponent<Canvas>();
            c.renderMode = RenderMode.ScreenSpaceOverlay;
            c.sortingOrder = orden;
            var s = go.AddComponent<CanvasScaler>();
            s.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            s.referenceResolution = new Vector2(W, H);
            s.screenMatchMode = CanvasScaler.ScreenMatchMode.Expand;
            return c;
        }

        // Raíz de 1456x819 centrada en el canvas
        public static RectTransform CrearRaiz(Transform canvas, string nombre)
        {
            var go = new GameObject(nombre, typeof(RectTransform));
            var rt = go.GetComponent<RectTransform>();
            rt.SetParent(canvas, false);
            rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 0.5f);
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.anchoredPosition = Vector2.zero;
            rt.sizeDelta = new Vector2(W, H);
            return rt;
        }

        public static RectTransform Rect(Transform p, string n, float x, float y, float w, float h)
        {
            var go = new GameObject(n, typeof(RectTransform));
            var rt = go.GetComponent<RectTransform>();
            rt.SetParent(p, false);
            rt.anchorMin = rt.anchorMax = new Vector2(0, 1);
            rt.pivot = new Vector2(0, 1);
            rt.anchoredPosition = new Vector2(x, -y);
            rt.sizeDelta = new Vector2(w, h);
            return rt;
        }

        public static Image Rellenar(Transform p, float x, float y, float w, float h, Color c)
        {
            var rt = Rect(p, "Rect", x, y, w, h);
            var im = rt.gameObject.AddComponent<Image>();
            im.color = c; im.raycastTarget = false;
            return im;
        }

        public static Caja NuevaCaja(Transform p, float x, float y, float w, float h, Color fill, Color? borde = null, float bw = 2f)
        {
            var rt = Rect(p, "Caja", x, y, w, h);
            var c = new Caja { rt = rt };
            if (borde.HasValue)
            {
                c.borde = rt.gameObject.AddComponent<Image>();
                c.borde.color = borde.Value; c.borde.raycastTarget = false;
                var inner = Rect(rt, "Relleno", bw, bw, w - 2 * bw, h - 2 * bw);
                c.fill = inner.gameObject.AddComponent<Image>();
            }
            else c.fill = rt.gameObject.AddComponent<Image>();
            c.fill.color = fill; c.fill.raycastTarget = false;
            return c;
        }

        public static Text Texto(Transform p, string s, float x, float y, float w, float h, int size, Color col,
            TextAnchor a = TextAnchor.UpperLeft, FontStyle st = FontStyle.Normal)
        {
            var rt = Rect(p, "Texto", x, y, w, h);
            var t = rt.gameObject.AddComponent<Text>();
            t.font = Fuente; t.text = s; t.fontSize = size; t.color = col; t.alignment = a; t.fontStyle = st;
            t.horizontalOverflow = HorizontalWrapMode.Wrap;
            t.verticalOverflow = VerticalWrapMode.Overflow;
            t.raycastTarget = false;
            return t;
        }

        public static ShootButton Boton(Transform p, string prefijo, string etiqueta, float x, float y, float w, float h,
            Action onClick, KeyCode tecla = KeyCode.None, bool relleno = false)
        {
            Color normal = relleno ? Paleta.Amarillo : new Color(0.09f, 0.11f, 0.08f, 0.95f);
            var caja = NuevaCaja(p, x, y, w, h, normal, Paleta.Amarillo, 2f);
            var sb = caja.rt.gameObject.AddComponent<ShootButton>();
            sb.onClick = onClick; sb.tecla = tecla; sb.relleno = caja.fill;
            sb.normal = normal;
            sb.resaltado = relleno ? new Color(1f, 0.87f, 0.55f) : new Color(0.27f, 0.23f, 0.10f, 0.98f);

            if (relleno)
                Texto(caja.rt, etiqueta, 0, 0, w, h, 17, Paleta.Oscuro, TextAnchor.MiddleCenter, FontStyle.Bold);
            else
            {
                if (!string.IsNullOrEmpty(prefijo))
                    Texto(caja.rt, prefijo, 20, 0, 70, h, 16, new Color(0.7f, 0.58f, 0.32f), TextAnchor.MiddleLeft, FontStyle.Bold);
                Texto(caja.rt, etiqueta, string.IsNullOrEmpty(prefijo) ? 20 : 78, 0, w - 90, h, 22, Paleta.Amarillo, TextAnchor.MiddleLeft, FontStyle.Bold);
            }
            return sb;
        }

        public static void Encabezado(Transform p, string izq, string der)
        {
            var c = NuevaCaja(p, 37, 28, 1383, 58, new Color(0.07f, 0.11f, 0.09f, 0.93f), Paleta.VerdeBorde, 2f);
            Texto(c.rt, izq, 22, 0, 700, 58, 17, Paleta.Verde, TextAnchor.MiddleLeft, FontStyle.Bold);
            if (!string.IsNullOrEmpty(der))
                Texto(c.rt, der, 1383 - 722, 0, 700, 58, 17, Paleta.Crema, TextAnchor.MiddleRight, FontStyle.Bold);
        }

        public static void Pie(Transform p, string izq, string der)
        {
            Texto(p, izq, 37, 776, 800, 20, 13, Paleta.Gris, TextAnchor.MiddleLeft, FontStyle.Bold);
            if (!string.IsNullOrEmpty(der))
                Texto(p, der, 619, 776, 800, 20, 13, Paleta.Gris, TextAnchor.MiddleRight, FontStyle.Bold);
        }

        // Ícono de Byte hecho con rectángulos (aprox. 60 x 64)
        public static void Byte(Transform p, float x, float y, float s = 1f)
        {
            var dark = new Color(0.27f, 0.31f, 0.26f);
            Rellenar(p, x + 16 * s, y, 28 * s, 4 * s, Paleta.Naranja);
            Rellenar(p, x, y + 5 * s, 60 * s, 52 * s, dark);
            Rellenar(p, x + 8 * s, y + 13 * s, 44 * s, 32 * s, Paleta.Verde);
            Rellenar(p, x + 18 * s, y + 21 * s, 6 * s, 6 * s, dark);
            Rellenar(p, x + 36 * s, y + 21 * s, 6 * s, 6 * s, dark);
            Rellenar(p, x + 20 * s, y + 34 * s, 20 * s, 3 * s, dark);
            Rellenar(p, x + 10 * s, y + 57 * s, 40 * s, 7 * s, new Color(0.20f, 0.23f, 0.19f));
        }

        public static void Dialogo(Transform p, float x, float y, float w, float h, string nombre, string texto, Color? colorNombre = null)
        {
            var c = NuevaCaja(p, x, y, w, h, Paleta.Panel, Paleta.Verde, 2f);
            Byte(c.rt, 26, 22, 1f);
            Texto(c.rt, nombre, 116, 20, w - 140, 20, 13, colorNombre ?? Paleta.Verde, TextAnchor.UpperLeft, FontStyle.Bold);
            Texto(c.rt, texto, 116, 46, w - 150, h - 56, 21, Paleta.Crema);
        }

        public static void Mira(Transform p, Color c)
        {
            float cx = W * 0.5f, cy = H * 0.5f, r = 16f, l = 8f, t = 2f;
            foreach (var sx in new[] { -1, 1 })
                foreach (var sy in new[] { -1, 1 })
                {
                    float hx = sx < 0 ? cx - r : cx + r - l;
                    float hy = sy < 0 ? cy - r : cy + r - t;
                    float vx = sx < 0 ? cx - r : cx + r - t;
                    float vy = sy < 0 ? cy - r : cy + r - l;
                    Rellenar(p, hx, hy, l, t, c);
                    Rellenar(p, vx, vy, t, l, c);
                }
            Rellenar(p, cx - 1, cy - 4, 2, 8, c);
            Rellenar(p, cx - 4, cy - 1, 8, 2, c);
        }
    }

    // ---------------------------------------------------------------
    //  Dibujo del mapa 7x7 en UI (minimapa / comparación / resumen)
    // ---------------------------------------------------------------
    public static class MapaUI
    {
        public static void Dibujar(Transform p, float x, float y, float lado, float gap,
            HashSet<Vector2Int> amarillo = null, HashSet<Vector2Int> verde = null, bool letras = true)
        {
            int n = Laberinto.N;
            float paso = lado / n, tam = paso - gap;
            for (int j = 0; j < n; j++)
                for (int i = 0; i < n; i++)
                {
                    var c = new Vector2Int(i, j);
                    Color col = Laberinto.Muro(c) ? Paleta.Muro : Paleta.Piso;
                    if (verde != null && verde.Contains(c)) col = Paleta.Verde;
                    if (amarillo != null && amarillo.Contains(c)) col = Paleta.Amarillo;
                    if (letras && c == Laberinto.A) col = Paleta.Amarillo;
                    if (letras && c == Laberinto.B) col = Paleta.Verde;
                    var im = UIKit.Rellenar(p, x + i * paso, y + j * paso, tam, tam, col);
                    if (letras && (c == Laberinto.A || c == Laberinto.B))
                    {
                        string l = c == Laberinto.A ? "A" : "B";
                        UIKit.Texto(im.transform, l, 0, 0, tam, tam, Mathf.RoundToInt(tam * 0.55f), Paleta.Oscuro, TextAnchor.MiddleCenter, FontStyle.Bold);
                    }
                }
        }

        // Línea de ruta (segmentos horizontales/verticales entre centros de celda)
        public static void Ruta(Transform p, float x, float y, float lado, List<Vector2Int> ruta, Color col, float grosor)
        {
            float paso = lado / Laberinto.N;
            for (int i = 0; i + 1 < ruta.Count; i++)
            {
                var a = ruta[i]; var b = ruta[i + 1];
                float ax = x + (a.x + 0.5f) * paso, ay = y + (a.y + 0.5f) * paso;
                float bx = x + (b.x + 0.5f) * paso, by = y + (b.y + 0.5f) * paso;
                float x0 = Mathf.Min(ax, bx) - grosor * 0.5f, y0 = Mathf.Min(ay, by) - grosor * 0.5f;
                float w = Mathf.Abs(ax - bx) + grosor, h = Mathf.Abs(ay - by) + grosor;
                UIKit.Rellenar(p, x0, y0, w, h, col);
            }
        }
    }

    // ---------------------------------------------------------------
    //  Base de las escenas 2D (1, 3 y 4)
    // ---------------------------------------------------------------
    public abstract class EscenaBase : MonoBehaviour
    {
        protected Canvas canvas;
        protected GameObject pantalla;
        Image velo;

        static void Estirar(RectTransform rt)
        {
            rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one; rt.offsetMin = rt.offsetMax = Vector2.zero;
        }

        static Image Capa(Transform padre, string nombre)
        {
            var go = new GameObject(nombre, typeof(RectTransform));
            go.transform.SetParent(padre, false);
            Estirar(go.GetComponent<RectTransform>());
            var im = go.AddComponent<Image>(); im.raycastTarget = false;
            return im;
        }

        // 0 = foto a pleno, 1 = negro
        protected void Oscurecer(float a) { if (velo != null) velo.color = new Color(0.04f, 0.07f, 0.06f, a); }

        protected virtual void Awake()
        {
            var cam = Camera.main;
            if (cam != null)
            {
                cam.clearFlags = CameraClearFlags.SolidColor;
                cam.backgroundColor = Paleta.Fondo;
            }
            canvas = UIKit.CrearCanvas("Canvas");
            var raizF = new GameObject("FondoRaiz", typeof(RectTransform));
            raizF.transform.SetParent(canvas.transform, false);
            Estirar(raizF.GetComponent<RectTransform>());
            var im = Capa(raizF.transform, "Fondo");
            im.color = Paleta.Fondo;
            var tex = Resources.Load<Texture2D>("Fondos/Taller");
            if (tex != null)
            {
                var go = new GameObject("Foto", typeof(RectTransform));
                go.transform.SetParent(raizF.transform, false);
                Estirar(go.GetComponent<RectTransform>());
                var raw = go.AddComponent<RawImage>(); raw.texture = tex; raw.raycastTarget = false;
            }
            velo = Capa(raizF.transform, "Velo");
            velo.color = new Color(0.04f, 0.07f, 0.06f, 0f);
            Cursor.lockState = CursorLockMode.None; Cursor.visible = true;
        }

        protected Transform NuevaPantalla()
        {
            if (pantalla != null) { pantalla.SetActive(false); Destroy(pantalla); }
            pantalla = UIKit.CrearRaiz(canvas.transform, "Pantalla").gameObject;
            return pantalla.transform;
        }

        protected void IrAEscena(string nombre) { SceneManager.LoadScene(nombre); }
    }
}
