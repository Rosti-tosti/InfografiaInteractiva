using UnityEditor;
using UnityEngine;
using UnityEditor.SceneManagement;
using System.Collections.Generic;

// Menú: Tools > Configurar 4 Escenas
// Regenera las 4 escenas (cada una con una cámara 2D ortográfica)
// y las agrega a Build Settings.
public static class ConfigurarEscenas
{
    [MenuItem("Tools/Configurar 4 Escenas")]
    public static void Configurar()
    {
        var colores = new[] {
            new Color(0.19f, 0.30f, 0.47f), new Color(0.20f, 0.40f, 0.25f),
            new Color(0.45f, 0.25f, 0.25f), new Color(0.35f, 0.25f, 0.45f)
        };
        var build = new List<EditorBuildSettingsScene>();

        for (int i = 1; i <= 4; i++)
        {
            string path = $"Assets/Scenes/Escena{i}.unity";
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            var go = new GameObject($"Camara2D_Escena{i}");
            go.tag = "MainCamera";
            go.transform.position = new Vector3(0, 0, -10);
            var cam = go.AddComponent<Camera>();
            cam.orthographic = true;
            cam.orthographicSize = 5f;
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = colores[i - 1];
            go.AddComponent<AudioListener>();

            EditorSceneManager.SaveScene(scene, path);
            build.Add(new EditorBuildSettingsScene(path, true));
        }
        EditorBuildSettings.scenes = build.ToArray();
        Debug.Log("4 escenas con cámara 2D creadas y agregadas a Build Settings.");
    }
}
