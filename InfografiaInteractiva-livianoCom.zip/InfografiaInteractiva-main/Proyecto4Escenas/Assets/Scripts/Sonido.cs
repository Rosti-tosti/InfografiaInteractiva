using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Pathfinding
{
    // Música y efectos de sonido de todo el proyecto.
    //  - Se crea sola al iniciar y sobrevive entre escenas (no hay que agregarla a ninguna escena).
    //  - Clips en Resources/Audio/Musica y Resources/Audio/Sfx (cargados por nombre).
    //  - Cada escena tiene su música; se cambia con fundido cruzado. Tecla M = silenciar / activar.
    // Uso desde cualquier script:  Sonido.Efecto("disparo");   Sonido.Musica("accion");
    public class Sonido : MonoBehaviour
    {
        const float VolumenMusica = 0.45f;
        const float VolumenEfectos = 0.9f;
        const float DuracionFundido = 1.2f;
        const int VocesEfectos = 12;

        static Sonido instancia;

        readonly Dictionary<string, AudioClip> cache = new Dictionary<string, AudioClip>();
        readonly List<AudioSource> voces = new List<AudioSource>();
        readonly AudioSource[] musica = new AudioSource[2];
        int activa;
        string musicaActual = "";
        bool silenciado;
        float fundido = 1f;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        static void Iniciar() { Obtener(); }

        static Sonido Obtener()
        {
            if (instancia == null)
            {
                var go = new GameObject("Sonido");
                DontDestroyOnLoad(go);
                instancia = go.AddComponent<Sonido>();
            }
            return instancia;
        }

        public static void Efecto(string nombre, float volumen = 1f, float tono = 1f)
        {
            Obtener().Reproducir(nombre, volumen, tono);
        }

        public static void Musica(string nombre)
        {
            Obtener().CambiarMusica(nombre);
        }

        // Música por defecto de cada escena (dentro de 01_Intro se cambia por código).
        static string MusicaDeEscena(string escena)
        {
            switch (escena)
            {
                case "Escena2": return "laberinto";
                case "Escena3": return "carrera";
                case "Escena4":
                case "Escena5": return "explicacion";
                default: return "menu";   // 01_Intro y Escena1
            }
        }

        void Awake()
        {
            for (int i = 0; i < musica.Length; i++) musica[i] = CrearFuente(true);
            for (int i = 0; i < VocesEfectos; i++) voces.Add(CrearFuente(false));
            SceneManager.sceneLoaded += AlCargarEscena;
        }

        void Start()
        {
            if (musicaActual.Length == 0) CambiarMusica(MusicaDeEscena(SceneManager.GetActiveScene().name));
        }

        void OnDestroy()
        {
            SceneManager.sceneLoaded -= AlCargarEscena;
            if (instancia == this) instancia = null;
        }

        AudioSource CrearFuente(bool bucle)
        {
            var src = gameObject.AddComponent<AudioSource>();
            src.playOnAwake = false;
            src.loop = bucle;
            src.spatialBlend = 0f;
            return src;
        }

        void AlCargarEscena(Scene escena, LoadSceneMode modo)
        {
            CambiarMusica(MusicaDeEscena(escena.name));
        }

        AudioClip Cargar(string ruta)
        {
            AudioClip clip;
            if (!cache.TryGetValue(ruta, out clip))
            {
                clip = Resources.Load<AudioClip>(ruta);
                if (clip == null) Debug.LogWarning("Sonido: no se encontró Resources/" + ruta);
                cache[ruta] = clip;
            }
            return clip;
        }

        void CambiarMusica(string nombre)
        {
            if (nombre == musicaActual) return;
            musicaActual = nombre;
            AudioClip clip = Cargar("Audio/Musica/" + nombre);
            int nueva = 1 - activa;
            musica[nueva].Stop();
            musica[nueva].clip = clip;
            musica[nueva].volume = 0f;
            if (clip != null) musica[nueva].Play();
            activa = nueva;
            fundido = 0f;
        }

        void Reproducir(string nombre, float volumen, float tono)
        {
            if (silenciado) return;
            AudioClip clip = Cargar("Audio/Sfx/" + nombre);
            if (clip == null) return;
            AudioSource libre = null;
            for (int i = 0; i < voces.Count; i++)
                if (!voces[i].isPlaying) { libre = voces[i]; break; }
            if (libre == null) libre = voces[0];
            libre.Stop();
            libre.clip = clip;
            libre.pitch = tono;
            libre.volume = VolumenEfectos * volumen;
            libre.Play();
        }

        void Update()
        {
            if (Input.GetKeyDown(KeyCode.M))
            {
                silenciado = !silenciado;
                if (silenciado) foreach (var v in voces) v.Stop();
            }

            fundido = Mathf.Min(1f, fundido + Time.unscaledDeltaTime / DuracionFundido);
            float objetivo = silenciado ? 0f : VolumenMusica;
            musica[activa].volume = objetivo * fundido;
            var saliente = musica[1 - activa];
            if (saliente.isPlaying)
            {
                saliente.volume = objetivo * (1f - fundido);
                if (fundido >= 1f) saliente.Stop();
            }
        }
    }
}
