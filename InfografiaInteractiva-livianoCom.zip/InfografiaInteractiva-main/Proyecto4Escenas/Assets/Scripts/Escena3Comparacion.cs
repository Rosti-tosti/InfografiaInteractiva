using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

namespace Pathfinding
{
    // Escena 3: carrera entre tu recorrido (amarillo) y la ruta A* (verde).
    // Los dos salen de A al mismo tiempo y avanzan un casillero por vez al mismo ritmo,
    // así se ve que la IA llega a B antes porque no da vueltas innecesarias.
    public class Escena3Comparacion : EscenaBase
    {
        const float MapaX = 87f, MapaY = 123f, MapaLado = 638f;
        const float DemoraInicio = 1.0f;

        class Corredor
        {
            public List<Vector2Int> ruta;
            public Color color;
            public float grosor;
            public Vector2 desfase;
            public RectTransform capa, marcador, parcial;
            public readonly List<RectTransform> tramos = new List<RectTransform>();
            public TMP_Text contador, insignia;
            public bool llego;
            public int Pasos { get { return ruta.Count - 1; } }
        }

        Corredor ia, jugador;
        TMP_Text txtEstado;
        float inicio, segundosPorPaso;
        int pasosJugador, pasosA, menos;
        bool sonoYa, sonoIA, sonoJugador;
        int ultimoPasoSonado = -1;

        void Start()
        {
            var recorrido = new List<Vector2Int>(DatosPartida.Recorrido);
            if (recorrido.Count < 2) recorrido = DemoRecorrido();   // por si se abre la escena sola

            var optima = AEstrella.Buscar(Laberinto.A, Laberinto.B);
            pasosJugador = recorrido.Count - 1;
            pasosA = optima.Count - 1;
            menos = Mathf.Max(0, pasosJugador - pasosA);
            int efectivo = RutaEfectiva(recorrido).Count - 1;

            Oscurecer(0.78f);
            var p = NuevaPantalla();
            UIKit.Encabezado(p, "Pathfinding/Sintetika", null);

            // Mapa limpio: los caminos se dibujan a medida que cada uno avanza.
            MapaUI.Dibujar(p, MapaX, MapaY, MapaLado, 5, null, null, true);

            // La capa de la IA va abajo y más gruesa; la tuya arriba y más fina, así se ven los dos
            // cuando coinciden en el mismo tramo.
            ia = new Corredor { ruta = optima, color = Paleta.Verde, grosor = 16f, desfase = new Vector2(-9, -9),
                capa = UIKit.Rect(p, "Camino_IA", 0, 0, UIKit.W, UIKit.H) };
            jugador = new Corredor { ruta = recorrido, color = Paleta.Amarillo, grosor = 8f, desfase = new Vector2(9, 9),
                capa = UIKit.Rect(p, "Camino_Jugador", 0, 0, UIKit.W, UIKit.H) };

            // A y B por encima de los caminos
            foreach (var c in new[] { Laberinto.A, Laberinto.B })
            {
                Vector2 pc = Centro(c);
                UIKit.Texto(p, c == Laberinto.A ? "A" : "B", pc.x - 20, pc.y - 20, 40, 40, 20, Paleta.Oscuro,
                    TextAnchor.MiddleCenter, FontStyles.Bold);
            }
            CrearMarcador(p, ia, "IA", Paleta.Verde);
            CrearMarcador(p, jugador, "VOS", Paleta.Amarillo);

            var panel = UIKit.NuevaCaja(p, 808, 123, 612, 635, Paleta.Panel, Paleta.Verde, 2f);
            UIKit.Byte(panel.rt, 26, 30, 1f);
            UIKit.RotuloDialogo(panel.rt, "BYTE / IA CORRUPTA", 150, 30, 430, 27, Paleta.Verde);
            UIKit.CuerpoDialogo(panel.rt, "Soy imbatible en esto.", 150, 65, 430, 56, Paleta.Crema);

            jugador.contador = Tarjeta(panel.rt, 154, "TU RECORRIDO / AMARILLO", "Costo mínimo: " + efectivo + " pasos.", Paleta.Amarillo, out jugador.insignia);
            ia.contador = Tarjeta(panel.rt, 258, "RUTA A* / VERDE", "Costo mínimo: " + pasosA + " pasos.", Paleta.Verde, out ia.insignia);

            txtEstado = UIKit.Texto(panel.rt, "SALEN DE A: VOS (AMARILLO) CONTRA LA IA (VERDE)", 33, 376, 540, 50, 14,
                Paleta.Amarillo, TextAnchor.UpperLeft, FontStyles.Bold);

            UIKit.Boton(p, "", "Repetir", 937, 695, 222, 47, () => IrAEscena("Escena3"), KeyCode.None, false);
            UIKit.Boton(p, "", "¿Cómo funciona?", 1182, 695, 222, 47, () => IrAEscena("Escena4"), KeyCode.Return, true);

            segundosPorPaso = Mathf.Clamp(9f / Mathf.Max(1, pasosJugador), 0.3f, 0.6f);
            inicio = Time.time;
            Sonido.Efecto("cuenta");
            Avanzar(ia, 0f);
            Avanzar(jugador, 0f);
        }

        static Vector2 Centro(Vector2Int c)
        {
            float paso = MapaLado / Laberinto.N;
            return new Vector2(MapaX + (c.x + 0.5f) * paso, MapaY + (c.y + 0.5f) * paso);
        }

        void CrearMarcador(Transform p, Corredor c, string texto, Color color)
        {
            var caja = UIKit.NuevaCaja(p, 0, 0, 38, 38, color, Paleta.Crema, 2f);
            UIKit.Texto(caja.rt, texto, 0, 0, 38, 38, 15, Paleta.Oscuro, TextAnchor.MiddleCenter, FontStyles.Bold);
            c.marcador = caja.rt;
        }

        TMP_Text Tarjeta(Transform panel, float y, string titulo, string sub, Color c, out TMP_Text insignia)
        {
            UIKit.Rellenar(panel, 33, y, 4, 77, c);
            UIKit.Texto(panel, titulo, 60, y + 12, 400, 18, 13, c, TextAnchor.UpperLeft, FontStyles.Bold);
            UIKit.Texto(panel, sub, 60, y + 36, 420, 28, 20, Paleta.Gris);
            insignia = UIKit.Texto(panel, "", 60, y + 60, 400, 16, 12, c, TextAnchor.UpperLeft, FontStyles.Bold);
            var numero = UIKit.Texto(panel, "0", 450, y + 12, 120, 60, 46, c, TextAnchor.MiddleRight, FontStyles.Bold);
            return numero;
        }

        void Update()
        {
            ShootButton.Procesar();
            if (ia == null) return;
            if (!sonoYa && Time.time - inicio >= DemoraInicio) { sonoYa = true; Sonido.Efecto("ya"); }
            float s = Mathf.Max(0f, (Time.time - inicio - DemoraInicio) / segundosPorPaso);
            Avanzar(ia, s);
            Avanzar(jugador, s);
            ActualizarTextos(s);
        }

        // Dibuja el camino recorrido y mueve el marcador. s = pasos transcurridos (con fracción).
        void Avanzar(Corredor c, float s)
        {
            float sc = Mathf.Min(s, c.Pasos);
            int k = Mathf.Min(Mathf.FloorToInt(sc), c.Pasos);
            float frac = sc - k;

            while (c.tramos.Count < k)
            {
                int i = c.tramos.Count;
                c.tramos.Add(NuevoTramo(c, Centro(c.ruta[i]), Centro(c.ruta[i + 1])));
            }

            Vector2 pos = k >= c.Pasos ? Centro(c.ruta[c.Pasos])
                : Vector2.Lerp(Centro(c.ruta[k]), Centro(c.ruta[k + 1]), frac);

            if (k < c.Pasos)
            {
                if (c.parcial == null) c.parcial = NuevoTramo(c, pos, pos);
                PonerTramo(c.parcial, Centro(c.ruta[k]), pos, c.grosor);
                c.parcial.gameObject.SetActive(true);
            }
            else if (c.parcial != null) c.parcial.gameObject.SetActive(false);

            Vector2 m = pos + c.desfase;
            c.marcador.anchoredPosition = new Vector2(m.x - 19, -(m.y - 19));
            c.contador.text = k.ToString();
            c.llego = k >= c.Pasos;
        }

        RectTransform NuevoTramo(Corredor c, Vector2 a, Vector2 b)
        {
            var im = UIKit.Rellenar(c.capa, 0, 0, 1, 1, c.color);
            PonerTramo(im.rectTransform, a, b, c.grosor);
            return im.rectTransform;
        }

        static void PonerTramo(RectTransform rt, Vector2 a, Vector2 b, float grosor)
        {
            float x0 = Mathf.Min(a.x, b.x) - grosor * 0.5f, y0 = Mathf.Min(a.y, b.y) - grosor * 0.5f;
            rt.anchoredPosition = new Vector2(x0, -y0);
            rt.sizeDelta = new Vector2(Mathf.Abs(a.x - b.x) + grosor, Mathf.Abs(a.y - b.y) + grosor);
        }

        void ActualizarTextos(float s)
        {
            if (s <= 0f) return;
            int pasoActual = Mathf.FloorToInt(s);
            if (pasoActual != ultimoPasoSonado)
            {
                ultimoPasoSonado = pasoActual;
                if (!ia.llego) Sonido.Efecto("tick", 0.6f, 1.5f);
                if (!jugador.llego) Sonido.Efecto("tick", 0.6f, 1f);
            }
            if (ia.llego && !sonoIA) { sonoIA = true; Sonido.Efecto("llegada_ia"); }
            if (jugador.llego && !sonoJugador) { sonoJugador = true; Sonido.Efecto("llegada_jugador"); }
            if (ia.llego && ia.insignia.text.Length == 0)
                ia.insignia.text = pasosA <= pasosJugador ? "¡LLEGÓ PRIMERA A B!" : "LLEGÓ A B";
            if (jugador.llego && jugador.insignia.text.Length == 0)
                jugador.insignia.text = pasosJugador > pasosA ? "LLEGÓ DESPUÉS" : "LLEGÓ A B";

            if (jugador.llego && ia.llego)
                txtEstado.text = menos + " PASOS MENOS · MISMO PUNTO B";
            else if (ia.llego)
                txtEstado.text = "LA IA YA LLEGÓ A B · VOS TODAVÍA ESTÁS EN EL PASO " + Mathf.Min(Mathf.FloorToInt(s), jugador.Pasos);
            else
                txtEstado.text = "LA IA Y VOS AVANZAN A LA VEZ · PASO " + Mathf.FloorToInt(s);
        }

        // Quita los desvíos (idas y vueltas) del recorrido para obtener la ruta efectiva
        static List<Vector2Int> RutaEfectiva(List<Vector2Int> r)
        {
            var res = new List<Vector2Int>();
            foreach (var c in r)
            {
                int i = res.IndexOf(c);
                if (i >= 0) res.RemoveRange(i + 1, res.Count - i - 1);
                else res.Add(c);
            }
            return res;
        }

        static List<Vector2Int> DemoRecorrido()
        {
            int[,] pts = { {1,1},{2,1},{3,1},{3,2},{3,3},{2,3},{1,3},{2,3},{3,3},{4,3},{5,3},{5,2},{5,1},{5,2},{5,3},{5,4},{5,5} };
            var l = new List<Vector2Int>();
            for (int i = 0; i < pts.GetLength(0); i++) l.Add(new Vector2Int(pts[i, 0], pts[i, 1]));
            return l;
        }
    }
}
